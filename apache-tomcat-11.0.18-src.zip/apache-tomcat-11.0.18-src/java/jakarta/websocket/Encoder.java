/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jakarta.websocket;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.nio.ByteBuffer;

public interface Encoder {

    /**
     * Initialise the encoder. The default implementation is a NO-OP.
     *
     * @param endpointConfig The end-point configuration
     */
    default void init(EndpointConfig endpointConfig) {
    }

    /**
     * Destroy the decoder. The default implementation is a NO-OP.
     */
    default void destroy() {
    }

    interface Text<T> extends Encoder {

        String encode(T object) throws EncodeException;
    }

    interface TextStream<T> extends Encoder {

        void encode(T object, Writer writer) throws EncodeException, IOException;
    }

    interface Binary<T> extends Encoder {

        ByteBuffer encode(T object) throws EncodeException;
    }

    interface BinaryStream<T> extends Encoder {

        void encode(T object, OutputStream os) throws EncodeException, IOException;
    }
}
